package com.aim17.myapplication.activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import com.aim17.myapplication.model.Task;
import com.aim17.myapplication.adapter.TaskAdapter;

import com.aim17.myapplication.R;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();

    RecyclerView recyclerView;
    TaskAdapter adapter;
    List<Task> testList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.taskListRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        testList = loadTasks();

        //createTaskList();

        adapter = new TaskAdapter(testList, R.layout.list_item);
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTask();
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_items, menu);
        return true;
    }

    @Override
    //Switch to options menu when toolbar icon is pressed.
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.settings_page:
                Intent intent = new Intent(this, OptionsMenu.class);
                startActivity(intent);

                return true;

            default:

                return super.onOptionsItemSelected(item);
        }
    }

    private void createTaskList() {
        /*
        Task task1 = new Task();
        task1.setName("Do Homework");
        task1.setDetails("Do homework for Software Engineering");
        Task task2 = new Task();
        task2.setName("Do Nothing");
        task2.setDetails("Do nothing at all");
        Task task3 = new Task();
        task3.setName("Do Something");
        task3.setDetails("Do something in this time");


        Log.d("todoapp", "CreateTaskList");

        List<Task> taskList = new ArrayList<>();

        testList.add(task1);
        testList.add(task2);
        testList.add(task3);

        Toast.makeText(getBaseContext(), "clicked Ok", Toast.LENGTH_SHORT).show();

        saveTasks(testList);
        testList = loadTasks();
*/
    }

    // Retrieves an arraylist of tasks from file storage
    public ArrayList<Task> loadTasks(){
        ArrayList<Task> retlist;
        FileInputStream finp;
        ObjectInputStream oinp;

        try {
            //finp = new FileInputStream("taskslist.ser");
            finp = openFileInput("taskslist.ser");
            oinp = new ObjectInputStream(finp);

            retlist = (ArrayList) oinp.readObject();

            oinp.close();
            finp.close();
            return retlist;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Log.d("loadTasks", "Failed to load tasks, returning null");
        return null;
    }


    public void saveTasks(List<Task> tasks){
        FileOutputStream fout;
        ObjectOutputStream oout;

        /*
         * Still need to add:
         * - Check if file already exists, and handle accordingly
         *  - If file doesnt exist, create file
         *  - If file does exist, replace contents (deleting old contents)
         * */

        try {
            //fout = new FileOutputStream("taskslist.ser");
            fout = openFileOutput("taskslist.ser", Context.MODE_PRIVATE);
            oout = new ObjectOutputStream(fout);

            oout.writeObject(tasks);

            oout.close();
            fout.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    //floating action button doesn't need View view parameter
    public void addTask() {
        final Task task = new Task();

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("                      Add Task");

        // Set up the input
        final EditText input = new EditText(this);
        final EditText input1 = new EditText(this);

        LinearLayout alertLayout = new LinearLayout(this);
        alertLayout.setOrientation(LinearLayout.VERTICAL);
        alertLayout.addView(input);
        alertLayout.addView(input1);
        builder.setView(alertLayout);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String taskTitle = input.getText().toString();
                String taskDesc = input1.getText().toString();
                task.setName(taskTitle);
                task.setDetails(taskDesc);
                testList.add(task);
                adapter.notifyDataSetChanged();
                saveTasks(testList);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();


    }

    public void editTask(View view) {


    }

    // This function requires api level 26+
    @RequiresApi(api = Build.VERSION_CODES.O)
    void sortTaskList(){
        // Simple bubble sort because fuck it

        boolean didSwap = true; // once no swaps were done, the list is sorted
        while (didSwap){
            didSwap = false;
            for (int i=0; i < testList.size()-2; i++){ // -2 because: size() is 1 bigger than max index, and we want second last element
                Task thiselement = testList.get(i);
                Task nextelement = testList.get(i+1);


                //  To support older api's, a version of this function using different comparison method is necessary (Not currently implemented)
                // compareTo returns positive if this is before argument (next).
                if (thiselement.getDue_date().compareTo(nextelement.getDue_date()) > 0){
                    didSwap = true;
                    testList.set(i, nextelement);
                    testList.set(i+1, thiselement);
                }
            }
        }
    }

}
